package com.goldencrow.android.blackraven;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.goldencrow.android.blackraven.entities.Monster;

public class FightActivity extends AppCompatActivity {

    // views from the opponent monster
    TextView mTvOpponentName;
    TextView mTvOpponentHealth;
    ImageView mIvOpponentImage;

    // views for myself
    TextView mTvSelfName;
    TextView mTvSelfHealth;
    ImageView mIvSelfImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fight);

        mTvOpponentName = findViewById(R.id.tv_opponent_name);
        mTvOpponentHealth = findViewById(R.id.tv_opponent_health);
        mIvOpponentImage = findViewById(R.id.iv_opponent_image);

        mTvSelfName = findViewById(R.id.tv_self_name);
        mTvSelfHealth = findViewById(R.id.tv_self_health);
        mIvSelfImage = findViewById(R.id.iv_self_image);

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("Opponent")) {
            Monster monster = intent.getParcelableExtra("Opponent");

            displayMonster(monster);
            editMonster();
        }
    }

    /**
     * Display all information about myself and the opponent monster.
     *
     * @param monster   the opponent monster.
     */
    private void displayMonster(Monster monster) {
        mTvOpponentName.setText(monster.getName());
        mTvOpponentHealth.setText(
                getString(R.string.health_display,
                    monster.getMaxHealth(),
                    monster.getMaxHealth()
                )
        );
        mIvOpponentImage.setImageResource(monster.getImage());

        mTvSelfName.setText("Colorful Colibri");
        mTvSelfHealth.setText(
                getString(R.string.health_display,
                        100,
                        100
                )
        );
        mIvSelfImage.setImageResource(R.drawable.ic_colibri_single_color);
    }

    /**
     * if the monster is of the category . . .
     *   . . ghost  -> 50% transparent
     *   . . shadow -> name in black shadows
     *   . . colorful -> name in colorful shadow
     */
    private void editMonster() {
        if (mTvOpponentName.getText().toString().toLowerCase().contains("ghost")) {
            mIvOpponentImage.setAlpha(0.5f);
        }
        if (mTvOpponentName.getText().toString().toLowerCase().contains("shadow")) {
            mTvOpponentName.setShadowLayer(10, 3, 3, Color.WHITE);
            mTvOpponentName.setTextColor(Color.GRAY);
        }

        if (mTvSelfName.getText().toString().toLowerCase().contains("colorful")) {
            mTvSelfName.setShadowLayer(10, 2, 2, Color.YELLOW);
            mTvSelfName.setTextColor(Color.WHITE);
        }
    }

    /**
     * Leave the fight (abort mission!!)
     *
     * @param view  which called it
     */
    public void leave_fight(View view) {
        finish();
    }

    /**
     * Open the inventory (requesting for help!!)
     *
     * @param view  which called it
     */
    public void open_inventory(View view) {
        Intent inventoryIntent = new Intent(this, InventoryActivity.class);

        startActivity(inventoryIntent);
    }
}
