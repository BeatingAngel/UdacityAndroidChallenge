package com.goldencrow.android.blackraven.entities;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * @author Philipp Hermüller
 * @version 14.11.2017
 */

public class Monster implements Parcelable {

    private String mName;
    private int mImage;
    private int mMaxHealth;

    public Monster(String name, int image, int maxHealth) {
        this.mName = name;
        this.mImage = image;
        this.mMaxHealth = maxHealth;
    }

    //region Getter

    public String getName() {
        return mName;
    }

    public int getImage() {
        return mImage;
    }

    public int getMaxHealth() {
        return mMaxHealth;
    }

    //endregion

    //region Parcelable functions

    protected Monster(Parcel in) {
        mName = in.readString();
        mImage = in.readInt();
        mMaxHealth = in.readInt();
    }

    public static final Creator<Monster> CREATOR = new Creator<Monster>() {
        @Override
        public Monster createFromParcel(Parcel in) {
            return new Monster(in);
        }

        @Override
        public Monster[] newArray(int size) {
            return new Monster[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(mName);
        parcel.writeInt(mImage);
        parcel.writeInt(mMaxHealth);
    }

    //endregion
}
