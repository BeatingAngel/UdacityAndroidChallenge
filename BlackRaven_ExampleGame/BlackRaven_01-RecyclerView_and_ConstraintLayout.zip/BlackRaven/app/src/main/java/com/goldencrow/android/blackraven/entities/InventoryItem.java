package com.goldencrow.android.blackraven.entities;

import com.goldencrow.android.blackraven.entities.enums.InventoryItemType;

/**
 * @author Philipp Hermüller
 * @version 14.11.2017
 */

public class InventoryItem {

    private String name;
    private InventoryItemType type;

    public InventoryItem(String name, InventoryItemType type) {
        this.name = name;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public InventoryItemType getType() {
        return type;
    }
}
